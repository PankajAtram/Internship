////////-----------------FOOTER CODE BELOW----------------------/////


import React from "react";

const Footer = props =>
{
    return(

        <div className="footer">
            <a href="#" className="terms">Terms and Conditions Privacy Policy © </a>
            <a href="#" className="follow">Follow Us</a>
    
        
        </div>
    )
}


export default Footer;