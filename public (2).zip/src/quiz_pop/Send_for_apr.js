import React from 'react'

function Send_for_apr() {
  return (
      <>
    <div className='send_head'>
        <h2 className='send_q_name'>Quiz Name</h2>
        <hr />
        <div className="send_content">
            <h2>description</h2>
            <h2>description</h2>
            <h2>description</h2>
        </div>
        <div className='edit_btn'>
            <button className='Edit_quiz' name='Edit_quiz'>Edit</button>
        </div>
    </div>
      </>
  )
}

export default Send_for_apr