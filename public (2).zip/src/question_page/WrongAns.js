import React from 'react'

function Wrongans() {
  return (
    <div className='Container'> 
        <p>
        Thank you 
        </p>
        <p>Your Score is 0*10 = 0</p>
      
       <button className='btn'>Go To Home</button>
      
    </div>
  )
}

export default Wrongans;