

 const SliderData = [
   {
     image: "build/asset/1.jpg",
   },
   {
     image: "build/asset/2.jpg",
   },
   {
     image: "build/asset/3.jpg",
   },
   {
     image: "build/asset/4.jpg",
   },
   {
     image:"build/asset/5.jpg"   },
 ];

export default SliderData;